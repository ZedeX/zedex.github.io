@echo off
cd /d "%~dp0"
set "fd=temp"
md "%fd%" 2>nul
for /f "delims=" %%a in ('dir /a-d/b *.lst') do (
    echo;"%%a"
    (for /f "tokens=1*delims=:" %%b in ('findstr /n .* "%%a"') do (
        set "f=%%c"
        if defined f (echo;file '%%c') else (echo;)
    ))>"%fd%\%%a"
    del "%%a"
    move /y "%fd%\%%a" "%%a"
)
echo;%w% +%#%%#% %zx%
rd temp