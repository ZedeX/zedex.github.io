del /f /s /q *.lst
