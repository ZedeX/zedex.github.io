@echo off
del /f /s /q *.jpeg
