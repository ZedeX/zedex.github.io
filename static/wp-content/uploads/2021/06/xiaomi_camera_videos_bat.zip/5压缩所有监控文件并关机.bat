for %%i in (*.lst) do (ffmpeg -hide_banner -f concat -safe 0 -i %%i -c:v libx265 -b:v 384k -c:a aac -s 1280x720 -vf scale=1280:720 -vf fps=20 %%i.mp4)

shutdown -f -s -t 1