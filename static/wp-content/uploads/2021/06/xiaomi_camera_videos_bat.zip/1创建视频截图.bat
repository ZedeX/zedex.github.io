@echo off
for /f "delims=" %%i in ('dir *.mp4 /b /s') do (ffmpeg -v quiet -y -i %%i -ss 1 -f image2 %%i.jpeg)